filename P2196784 list;
 %put NOTE- ;
 %put NOTE: Data for package maxims4sas, version 0.2.4, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-07-27T18:24:15; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(maxims4sas) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package maxims4sas, version 0.2.4, license MIT;
%put NOTE- *** END ***;
/* lazydata.sas end */
